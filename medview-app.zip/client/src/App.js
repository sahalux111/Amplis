import React, { useState } from "react";
import Upload from "./components/Upload";
import DicomViewer from "./components/DicomViewer";
import VideoCall from "./components/VideoCall";

function App() {
  const [imageUrl, setImageUrl] = useState(null);
  return (
    <div>
      <h1>MedView TeleHealth Prototype</h1>
      <VideoCall />
      <Upload onFileUploaded={setImageUrl} />
      {imageUrl && <DicomViewer imageUrl={imageUrl} />}
    </div>
  );
}
export default App;
