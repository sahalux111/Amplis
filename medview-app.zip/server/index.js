const express = require('express');
const http = require('http');
const socketIO = require('socket.io');
const uploadRoutes = require('./routes/upload');
const socketHandler = require('./socket');

const app = express();
const server = http.createServer(app);
const io = socketIO(server, {
  cors: { origin: '*' }
});

app.use(express.static('uploads'));
app.use('/api/upload', uploadRoutes);

io.on('connection', socket => socketHandler(io, socket));

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => console.log(`Server listening on ${PORT}`));
