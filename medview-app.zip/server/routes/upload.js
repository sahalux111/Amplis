const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const router = express.Router();
const upload = multer({ dest: '/tmp/' });

router.post('/', upload.single('file'), (req, res) => {
  const tmpPath = req.file.path;
  const newPath = path.join(__dirname, '../../uploads', req.file.originalname);
  fs.rename(tmpPath, newPath, () => {
    res.json({ url: `/uploads/${req.file.originalname}` });
  });
});

module.exports = router;
