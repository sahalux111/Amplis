module.exports = (io, socket) => {
  console.log('User connected:', socket.id);

  socket.on('signal', payload => {
    io.emit('signal', payload);
  });

  socket.on('dicom-interaction', data => {
    socket.broadcast.emit('dicom-interaction', data);
  });

  socket.on('disconnect', () => {
    console.log('User disconnected:', socket.id);
  });
};
